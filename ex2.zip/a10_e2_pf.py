import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as col
import math

import utils_ekf as utekf

# Close all plot windows
plt.close("all")

"""
Import parameters from utils file
"""
l = utekf.l
stepSize = utekf.stepSize
landmarks = utekf.landmarks

print("Robot width: " + str(l))
print("Landmarks: \n" + str(landmarks))



"""
IMPLEMENT YOUR FUNCTIONS BELOW:
take a look at the definition of 'particle_filter' below to get an overview where your functions will be used
"""

def motion(xt, u):
    v, psi, t = u
    x,y,theta, w = xt
    R = np.eye(3) * (0.05 ** 2)
    rx, ry, rtheta = np.random.multivariate_normal([0, 0, 0], R).T
    """
    YOUR CODE HERE (a)
    """
    return (x+rx, y+ry, theta+rtheta, w)

def measurement(xt, landmarks):
    """
    Returns the predicted range measurements for the landmarks,
    given the pose xt.
    Returns a list of ranges.
    """
    x, y, theta, w = xt
    z = []
    """
    YOUR CODE HERE (b)
    """
    return z

def reweight(P, zt, landmarks):
    """
    Calculates the weights for each particle given the current measurement.
    Returns a new set of particles with adjusted weights.
    Each weight is defined as the probability density of the measurement model,
    evaluated at the actual measurement.
    Invariant: The sum over all weights must be 1
    """

    Pnew = P
    """
    YOUR CODE HERE (c)
    """
    return Pnew

def resample(P):
    """
    Performs importance sampling to calulate a new set of particles
    """

    Pnew = P
    """
    YOUR CODE HERE (d)
    """
    return Pnew



"""
Predefined functions, do not change
"""
def particle_filter(P, commands, measurements, landmarks):
    # initialize time and
    time = 0
    colorIdx = 0

    for u in commands:
        # 2.a) apply the motion model to all particles
        P = [motion(xt, u) for xt in P]

        for z in measurements:
            if z[0] == time:
                # 2b, 2c) reweight all particles whenever we have a measurement for a specific time
                P = reweight(P, z[1], landmarks)

                # 2d) apply importance sampling to all particles
                P = resample(P)

        # plot all Particles over all time steps
        plotParticles(P, colors[colorIdx])

        # update time steps (and new color for new time step)
        time += stepSize
        colorIdx += 1

N = 300

def generateParticle(x, y, theta, pcov):
    rx, ry, rtheta = np.random.multivariate_normal([x, y, theta], pcov).T
    return np.array([rx, ry, rtheta, 1. / N])


def plotParticles(P, color):
    x, y, theta, w = zip(*P)

    arrow_scale = 0.2
    xu = [arrow_scale * d for d in map(np.cos, theta)]
    xv = [arrow_scale * d for d in map(np.sin, theta)]

    axes.quiver(x, y, xu, xv, angles='xy', scale_units='xy', units='dots', scale=2, color=color)


np.random.seed(100)

startPose = np.array([0, 0, 0])
odometry = utekf.ReadOdometry('odometry.txt')

commands = []

for i in range(0, len(odometry)):
    o = odometry[i]
    u = np.append(utekf.WheelToRobot(o[0:2], l), o[2])
    commands.append(u)

measurements = utekf.ReadMeasurements('measurements.txt')
trajectory = utekf.OdomToTrajectory(startPose, odometry)

print('Trajectory from noisy odometry')
utekf.PlotTrajectory(trajectory)

print('Trajectory from noisy odometry with measurements')
utekf.PlotTrajectoryMeasurements(trajectory, measurements)

# initial position is known
pcov = [[0.0, 0, 0],
        [0, 0.0, 0],
        [0, 0, 0.0]]

# generate N particles at the starting position
P = [generateParticle(startPose[0], startPose[1], startPose[2], pcov) for i in range(N)]

# run particle filter and plot
fig = plt.figure()
axes = fig.add_subplot(111, aspect='equal')
axes.clear()

plotParticles(P, 'r')

cmap = plt.get_cmap('prism')
colors = col.makeMappingArray(len(commands), cmap)

particle_filter(P, commands, measurements, landmarks)
plt.show()

