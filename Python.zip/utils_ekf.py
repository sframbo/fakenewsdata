# -*- coding: utf-8 -*-
"""
Created on Wed Jun 19 11:01:41 2019

@author: jordan
"""
import numpy as np
import matplotlib.pyplot as plt
import math
from matplotlib.patches import Ellipse

landmarks = np.array([[1,8.5]])

l = 0.5

stepSize = 0.5


def ReadCommands(filename):
    f = open(filename, 'r')
    f.readline()
    startPose = np.array([float(val) for val in f.readline().split(';')])
    f.readline()
    commands = []
    for line in f:
        if len(line) > 2:
            commands.append(np.array([float(val) for val in line.split(';')]))
    return commands, startPose


def ReadOdometry(filename):
    f = open(filename, 'r')
    odometry = []
    curTime = 0
    times = [curTime]
    header = True
    for line in f:
        if header:
            header = False
            continue
        if len(line) > 2:
            odometry.append(np.array([float(val) for val in line.split(';')]))
            curTime = curTime + odometry[len(odometry) - 1][2]
            times.append(curTime)
    return odometry, times


def ReadMeasurements(filename):
    f = open(filename, 'r')
    measurements = []
    header = True
    for line in f:
        if header:
            header = False
            continue
        if len(line) > 2:
            tl = line.split(';')
            ml = [[float(tl[i]), float(tl[i + 1])] for i in range(1, len(tl) - 1, 2)]
            measurements.append([(float(tl[0])), ml])
    return measurements

# check if measurements are available
def GetMeasurementTime(measurements, t):
    tm = [[-1, -1], [-1, -1], [-1, -1]]
    for m in measurements:
        if np.abs(m[0] - t) < 0.00001:
            return 1, m[1]
    return 0, tm

# convert odometry to robot velocities (v_linear, w_angle), it's the control input u(t)
def OdomToRobotVel(u, l, t):
    return np.array([(u[0] + u[1]) / 2.0, (u[1] - u[0]) / l]) * (1.0 / t)

# used in UpdatePose function
def CalcRadiusFromCommand(c):
    if np.abs(c[1]) < 0.00001:
        return np.inf
    return c[0] / c[1]

# using differential drive motion model to update the state
def UpdatePose(pose, command):
    v, omega,t = command
    x,y,theta = pose
    rv = [v,omega]
    r = CalcRadiusFromCommand(rv)
    if (r == np.inf):
        dp =  np.array([np.cos(theta)*v*t,np.sin(theta)*v*t,0])
        return pose+ dp
    else:
        dp = np.array( [r*(np.sin(theta+ omega*t) - np.sin(theta) ),r*(-np.cos(theta+ omega*t) + np.cos(theta) ), omega*t ])
        return pose+ dp


def CalcRadiusFromWheel(wv, l):
    if (wv[1] - wv[0]) == 0:
        return np.inf
    return ((wv[0] + wv[1]) * l) / ((wv[1] - wv[0]) * 2)


def CalcDTheta(u, l):
    return (u[1] - u[0]) / l


def UpdatePoseOdom(pose, o, l):
    x, y, theta = pose
    r = CalcRadiusFromWheel(o, l)
    delTheta = CalcDTheta(o, l)

    if r == np.inf:
        s = o[0]
        dp = np.array([np.cos(theta) * s, np.sin(theta) * s, 0])
        return pose + dp
    else:
        dp = np.array(
            [r * (np.sin(theta + delTheta) - np.sin(theta)), r * (-np.cos(theta + delTheta) + np.cos(theta)), delTheta])
        return pose + dp

# convert odometry to traj to see how the traj looks like. just for testing
def OdomToTrajectory(startPose, odom, l):
    trajectory = [startPose]
    curPose = startPose
    for c in odom:
        curPose = UpdatePoseOdom(curPose, c, l)
        trajectory.append(curPose)
    return trajectory


def GetMinMax(traj):
    border = 1
    points = [[t[0], t[1]] for t in traj]
    p = np.array(points)
    minT = np.amin(p, axis=0)
    maxT = np.amax(p, axis=0)
    print("min max : " + str([minT[0], maxT[0], minT[1], maxT[1]]))
    return [minT[0] - border, maxT[0] + border, minT[1] - border, maxT[1] + border]


def PlotTrajectoryCommands(startPose, commands):
    fig = plt.figure()
    trajectory = [startPose]
    curPose = startPose
    for c in commands:
        curPose = UpdatePose(curPose, c)
        trajectory.append(curPose)

    pTra = [t[:2] for t in trajectory]
    plt.plot(*zip(*pTra), marker='o', color='r', ls='solid')
    for t in trajectory:
        plt.plot([t[0], t[0] + np.cos(t[2])], [t[1], t[1] + np.sin(t[2])], color='b', ls='solid')
    plt.axis(GetMinMax(trajectory))
    plt.plot(*zip(*landmarks), marker='o', color='b', ls='solid')
    plt.show()


def PlotTrajectory(trajectory):
    fig = plt.figure()
    pTra = [t[:2] for t in trajectory]
    plt.plot(*zip(*pTra), marker='o', color='r', ls='solid')
    for t in trajectory:
        plt.plot([t[0], t[0] + np.cos(t[2])], [t[1], t[1] + np.sin(t[2])], color='b', ls='solid')
    plt.axis(GetMinMax(trajectory))
    plt.plot(*zip(*landmarks), marker='o', color='b', ls='solid')
    plt.show()


def PlotTrajectoryMeasurements(trajectory, measurements, times):
    fig = plt.figure()
    pTra = [t[:2] for t in trajectory]
    plt.plot(*zip(*pTra), marker='o', color='r', ls='solid')
    for i in range(0, len(trajectory)):
        t = trajectory[i]
        time = times[i]
        plt.plot([t[0], t[0] + np.cos(t[2])], [t[1], t[1] + np.sin(t[2])], color='b', ls='solid')
        hasM, m = GetMeasurementTime(measurements, time)

        if hasM == 1:
            for tm in m:
                # print(tm)
                plt.plot([t[0], t[0] + np.cos(t[2] + tm[1]) * tm[0]], [t[1], t[1] + np.sin(t[2] + tm[1]) * tm[0]],
                         color='g', ls='solid')

    plt.axis(GetMinMax(trajectory))
    plt.plot(*zip(*landmarks), marker='o', color='b', ls='solid')
    plt.show()

# plot the covariance as a ellipse
def PlotEllipse(cov, pos, volume=.01, ax=None, fc='none', ec=[0, 0, 0], a=1, lw=1):
    """
    Plots an ellipse enclosing *volume* based on the specified covariance
    matrix (*cov*) and location (*pos*). Additional keyword arguments are passed on to the 
    ellipse patch artist.

    Parameters
    ----------
        cov : The 2x2 covariance matrix to base the ellipse on
        pos : The location of the center of the ellipse. Expects a 2-element
            sequence of [x0, y0].
        volume : The volume inside the ellipse; defaults to 0.5
        ax : The axis that the ellipse will be plotted on. Defaults to the 
            current axis.
    """
    from scipy.stats import chi2

    def eigsorted(cov):
        vals, vecs = np.linalg.eigh(cov)
        order = vals.argsort()[::-1]
        return vals[order], vecs[:, order]

    if ax is None:
        ax = plt.gca()

    vals, vecs = eigsorted(cov)
    theta = np.degrees(np.arctan2(*vecs[:, 0][::-1]))

    kwrg = {'facecolor': fc, 'edgecolor': ec, 'alpha': a, 'linewidth': lw}

    # Width and height are "full" widths, not radius
    width, height = 2 * np.sqrt(chi2.ppf(volume, 2)) * np.sqrt(vals)
    ellip = Ellipse(xy=pos, width=width, height=height, angle=theta, **kwrg)

    ax.add_artist(ellip)


def PlotStates(states, covariance):
    fig = plt.figure()
    pTra = [t[:2] for t in states]
    plt.plot(*zip(*pTra), marker='o', color='r', ls='solid')
    for i in range(0, len(states)):
        t = states[i]
        cov = covariance[i]
        plt.plot([t[0], t[0] + np.cos(t[2])], [t[1], t[1] + np.sin(t[2])], color='b', ls='solid')
        PlotEllipse(cov[0:2, 0:2], t)

    plt.axis(GetMinMax(pTra))
    plt.plot(*zip(*landmarks), marker='o', color='b', ls='solid')
    plt.show()


def PlotStatesMeasurementes(states, covariance, measurements, times):
    fig = plt.figure()
    pTra = [t[:2] for t in states]
    plt.plot(*zip(*pTra), marker='o', color='r', ls='solid')
    for i in range(0, len(states)):
        time = times[i]
        t = states[i]
        cov = covariance[i]
        plt.plot([t[0], t[0] + np.cos(t[2])], [t[1], t[1] + np.sin(t[2])], color='b', ls='solid')
        PlotEllipse(cov[0:2, 0:2], t)
        hasM, m = GetMeasurementTime(measurements, time)
        if (hasM == 1):
            for tm in m:
                plt.plot([t[0], t[0] + np.cos(t[2] + tm[1]) * tm[0]], [t[1], t[1] + np.sin(t[2] + tm[1]) * tm[0]],
                         color='g', ls='solid')

    plt.axis(GetMinMax(pTra))
    plt.plot(*zip(*landmarks), marker='o', color='b', ls='solid')
    plt.show()
