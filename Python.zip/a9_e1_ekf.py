import numpy as np
import matplotlib.pyplot as plt
import math
from matplotlib.patches import Ellipse

import utils_ekf as utekf

# Close all plot windows
plt.close("all")

"""
Import parameters from utils file
"""
l = utekf.l
landmarks = utekf.landmarks
stepSize = utekf.stepSize

print("Robot width: " + str(l))
print("Step Size: " + str(stepSize))
print("Landmarks: \n" + str(landmarks))
   
   
"""  
Read data from files
Commands are just for visualization
Use noiseOdometry for c)
Use noiseOdometry and noiseMeasurements for d)

IMPORTANT: the first entry in the measurement array is the time at which the measurement was taken, 
followed measurements (distance,angle). Make sure to use the measurements at the correct timesteps.
"""
commands, startPose = utekf.ReadCommands('commands.txt')
noiseOdometry,times = utekf.ReadOdometry('odometry.txt')
noiseMeasurements = utekf.ReadMeasurements('measurements.txt')


print('Trajectory from commands')
utekf.PlotTrajectoryCommands(startPose,commands)

trajectory = utekf.OdomToTrajectory(startPose,noiseOdometry,l)

print('Trajectory from noisy odometry')
utekf.PlotTrajectory(trajectory)

print('Trajectory from noisy odometry with measurements')
utekf.PlotTrajectoryMeasurements(trajectory,noiseMeasurements,times)


"""
Initial values for covariance and start pose
"""
x = (np.array([0.0,0.0,0.0]))
P = np.identity(x.shape[0])*0.1


"""
Predefined covariance matrices for system noise R and measurement noise Q. 
"""
Q = np.identity(2)*0.1
R = np.identity(x.shape[0])*0.1


"""  
c) Implement the prediction step of the Extended Kalman Filter here
Hint: You can use your own differential drive motion model from slides or use a UpdatePoseXXX function from utekf
Hint: You can convert the odometry measurements to control commands to update the motion model using UpdatePose(pose, command)
"""


"""  
The result of c) should be a list of states and covariance matrices, use PlotStates(states,covariances) to plot them 
"""
#PlotStates(statesO,covarsO)



"""  
d) Implement the Extended Kalman Filter by including the measurements here

Hint: Use utekf.GetMeasurementTime(noiseMeasurements,curTime+stepSize)
"""



"""  
Plot results of d) together with the measurements. Check if robot poses and measurements correspond to the fixed landmark locations.
"""
#PlotStatesMeasurementes(statesM,covarsM,noiseMeasurements,times)
