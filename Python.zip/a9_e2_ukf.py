# -*- coding: utf-8 -*-
"""
Created on Thursday Jun 23

@author: Nuri benbarka

Modified on Monday 28 Jun 2021
"""
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Ellipse

import utils_ekf as utils

landmarks = np.array([[0, 2], [5, 1], [7, 1.5]])

l = 0.5


def PlotEllipse(cov, pos, volume=0.5, ax=None, fc='none', ec=[0, 0, 0], a=1, lw=1):
    """
    Plots an ellipse enclosing *volume* based on the specified covariance
    matrix (*cov*) and location (*pos*). Additional keyword arguments are passed on to the
    ellipse patch artist.

    Parameters
    ----------
        cov : The 2x2 covariance matrix to base the ellipse on
        pos : The location of the center of the ellipse. Expects a 2-element
            sequence of [x0, y0].
        volume : The volume inside the ellipse; defaults to 0.5
        ax : The axis that the ellipse will be plotted on. Defaults to the
            current axis.
    """

    def eigsorted(cov):
        vals, vecs = np.linalg.eigh(cov)
        order = vals.argsort()[::-1]
        return vals[order], vecs[:, order]

    if ax is None:
        ax = plt.gca()

    vals, vecs = eigsorted(cov)
    theta = np.degrees(np.arctan2(*vecs[:, 0][::-1]))

    kwrg = {'facecolor': fc, 'edgecolor': ec, 'alpha': a, 'linewidth': lw}

    # Width and height are "full" widths, not radius
    # width, height = 2 * np.sqrt(chi2.ppf(volume,2)) * np.sqrt(vals)
    width, height = 2 * np.sqrt(vals)
    ellip = Ellipse(xy=pos, width=width, height=height, angle=theta, **kwrg)

    ax.add_artist(ellip)


def PlotDistribution(points, meanReal, covReal, Sigmas, meanSigma, covSigma, meanLin=None, covLin=None):
    if covLin is None:
        covLin = []
    if meanLin is None:
        meanLin = []
    plt.scatter(*zip(*points), color='c', s=2, label="samples")
    plt.scatter(*zip(*Sigmas), s=95, label="sigma points")
    PlotEllipse(covReal, meanReal, ec='r', lw=3)
    PlotEllipse(covSigma, meanSigma, ec='g', lw=2)
    if len(meanLin) > 0:
        PlotEllipse(covLin, meanLin, ec='b', lw=3)
    # plt.axis([-0.5, 1.5, -1.5, 1.5])
    plt.show()


def MatrixSqrtE(A):
    ev, evec = np.linalg.eig(A)
    diag = np.diag(ev)
    return np.dot(evec, np.sqrt(diag)).dot(np.linalg.inv(evec))


def NormalDistributionToSigmaPoint(mean, covar, w0):
    print('use the MatrixSqrtE function to help you')
    pass


def SigmaPointsToNormalDistribution(SP, w):
    pass


def Warp(x):
    pass


def WarpPoints(x):
    return np.array([Warp(v) for v in x])


def GetWarpJacobian(x):
    pass


def WarpSigmaPoints(SP, c):
    return np.array([(utils.UpdatePose(x, c)) for x in SP])


if __name__ == "__main__":
    W0 = 0.4
    u = np.array([2.5, 2.0])
    S = np.array([[0.1 ** 2, 0], [0, 0.6 ** 2]])
    print("(a)")
    print("mean mu = ", u)
    print("covariance sigma = \n", S)

    Sig = NormalDistributionToSigmaPoint(u, S, W0)
    if Sig is not None:
        SigmaPoints, Weights = Sig
        print("sigma points (mu,sigma): \n", SigmaPoints)
        print("weights: ", Weights)
    else:
        print("implement the NormalDistributionToSigmaPoint function")

    print("(b)")
    Test = SigmaPointsToNormalDistribution(SigmaPoints, Weights)
    if Test is not None:
        TestSMean, TestSCov = Test
        print("sigma to normal dist:")
        print("mu = ", TestSMean)
        print("cov = \n", TestSCov)
    else:
        print("implement the SigmaPointsToNormalDistribution function")

    points = np.random.multivariate_normal(u, S, 5000)

    PlotDistribution(points, u, S, SigmaPoints, TestSMean, TestSCov)
    print("(c)")
    WSigma = WarpPoints(SigmaPoints)
    if WSigma is not None:
        WMean, WCov = SigmaPointsToNormalDistribution(WSigma, Weights)
        print("warp mean = ", WMean)
        print("warp cov = \n", WCov)
        WPoints = WarpPoints(points)
        WPMean = np.mean(WPoints.T, axis=1)
        WPCov = np.cov(WPoints.T)
    else:
        print("implement the Warp function")

    print("(d)")
    Jac = GetWarpJacobian(u)
    if Jac is not None:
        print("Jacobian on mu_last: ", Jac)
        print(np.matmul(GetWarpJacobian(u), np.matmul(S, (GetWarpJacobian(u).transpose()))))
        WLMean = Warp(u)
        G = GetWarpJacobian(WLMean)
        WLCov = G.dot(S).dot(np.transpose(G))
        print("lin. warp mu = ", WLMean)
        print("Jacobian on mu_now: \n", G)
        print("lin. warp sigma = ", WLCov)
        PlotDistribution(WPoints, WPMean, WPCov, WSigma, WMean, WCov, WLMean, WLCov)
    else:
        print("implement the GetWarpJacobian function")

    commands, startPose = utils.ReadCommands('commands.txt')
    x = (np.array(startPose))
    u = np.array([commands[0][0], commands[0][1]])
    P = np.identity(x.shape[0]) * 0.5
    Q = np.identity(x.shape[0]) * 0.9
    R = np.identity(x.shape[0]) * 0.05
    lx = len(x)

    states = [x]
    covars = [P]
    for c in commands:
        print('implement (e) here')

    print('Commands:')
    utils.PlotStates(states, covars)
    print('------------------------------------------')
